package com.projeto.projetoFabinho.DAO;

public class StockDAO {

}
