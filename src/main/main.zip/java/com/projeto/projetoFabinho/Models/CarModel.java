package com.projeto.projetoFabinho.Models;

public class CarModel {
    private int codigo;
    private int codigoCliente;
    private String situacao;
    private String marca;
    private String modelo;
    private String anoModelo;
    private String placa;
    private String observacoes;

    // Construtor
    public CarModel(int codigo, int codigoCliente, String situacao, String marca, String modelo, String anoModelo, String placa, String observacoes) {
        this.codigo = codigo;
        this.codigoCliente = codigoCliente;
        this.situacao = situacao;
        this.marca = marca;
        this.modelo = modelo;
        this.anoModelo = anoModelo;
        this.placa = placa;
        this.observacoes = observacoes;
    }

    public CarModel() {
        // Construtor vazio para inicialização
    }

    // Getters e Setters
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }

    public int getCodigoCliente() { return codigoCliente; }
    public void setCodigoCliente(int codigoCliente) { this.codigoCliente = codigoCliente; }

    public String getSituacao() { return situacao; }
    public void setSituacao(String situacao) { this.situacao = situacao; }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getAnoModelo() { return anoModelo; }
    public void setAnoModelo(String anoModelo) { this.anoModelo = anoModelo; }

    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}
